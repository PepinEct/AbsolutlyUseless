# AbsolutlyUseless

Only do stuff if u know what it does lol
For java jdk visit: https://download.java.net/java/GA/jdk19.0.1/afdd2e245b014143b62ccb916125e3ce/10/GPL/openjdk-19.0.1_windows-x64_bin.zip
